#!/usr/bin/python3
"""
ThismoduledefinesRectangleclassrepresentrectangle with width and height attrib.
The width and height must be non-negative integers.
"""


class Rectangle:
    """
    This class defines an empty rectangle.
    """
    pass
