so far the good and more undersandable and approachablepython import module  project
