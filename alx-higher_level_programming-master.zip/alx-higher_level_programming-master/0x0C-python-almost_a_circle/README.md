pyhton circle project revision for All concepts
