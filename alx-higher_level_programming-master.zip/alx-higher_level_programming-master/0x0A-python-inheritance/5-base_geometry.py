#!/usr/bin/python3
"""
This module contains the BaseGeometry class.
"""


class BaseGeometry:
    """
    An empty class representing BaseGeometry.
    """
    pass
