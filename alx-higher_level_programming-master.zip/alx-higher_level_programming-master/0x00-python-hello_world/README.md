alx tough from begiinig pythin projects special the advanced ones 
