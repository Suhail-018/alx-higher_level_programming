#!/usr/bin/python3
number = 98
print(f"{number} Battery street")
