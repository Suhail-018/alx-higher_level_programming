#!/usr/bin/python3
class LockedClass:
    slots = ['first_name']
