#!/usr/bin/python3
def pow(a, b):
    result = a ** b
    return result
