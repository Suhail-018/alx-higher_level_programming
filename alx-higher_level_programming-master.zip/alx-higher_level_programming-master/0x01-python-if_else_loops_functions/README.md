second python project if and for conditoins
