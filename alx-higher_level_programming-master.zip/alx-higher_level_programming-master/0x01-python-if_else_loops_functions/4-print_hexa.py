#!/usr/bin/python3
for i in range(99):
    print("{} = 0x{:x}".format(i, i))
