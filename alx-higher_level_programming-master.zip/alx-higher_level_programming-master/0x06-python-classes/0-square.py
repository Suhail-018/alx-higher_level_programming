#!/usr/bin/python3
"""
This is a module that defines a class Square.
"""


class Square:
    """
    This is a class that defines a square.

    A square is a geometric shape with four equal sides and four right angles.

    Attributes:
        No attributes are defined in this class.
    """

    pass
