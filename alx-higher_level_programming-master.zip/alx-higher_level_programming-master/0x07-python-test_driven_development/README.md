my test driven python project
