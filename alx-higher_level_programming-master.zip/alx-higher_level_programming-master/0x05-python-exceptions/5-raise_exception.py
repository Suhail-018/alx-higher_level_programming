#!/usr/bin/python3
def raise_exception():
    raise TypeError("Exception raised")  # Raise a TypeError exception
