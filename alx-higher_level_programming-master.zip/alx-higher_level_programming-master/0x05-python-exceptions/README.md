exceptions and error project.
