#!/usr/bin/python3

def number_keys(a_dictionary):
    num_keys = len(a_dictionary)
    return num_keys
